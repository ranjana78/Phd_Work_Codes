
#---------------------------------Importing Packages----------------------------
import scipy
import datetime
import sys
from sklearn.preprocessing import normalize
#import tensorflow as tf
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from iteration_utilities import flatten
from geopy.distance import geodesic
from sklearn.metrics import roc_auc_score
import csv
import os
import time
import cv2
import sys
from sklearn import metrics
import shutil
import random
import math
import PIL
import pickle
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from PIL import Image
from numpy import asarray
from numpy import array
from numpy import linalg as LA
from collections import Counter
from numpy import dot
from numpy.linalg import norm
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision import transforms
from functools import reduce
import json
from itertools import combinations
import matplotlib.pyplot as plt
import torch.nn as nn
from torch.optim import Adam
import torchvision
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from scipy import misc,ndimage
import multiprocessing as mp
import pywt
import pywt.data
import statistics
from scipy.stats import entropy
from statistics import mean
from sklearn.model_selection import KFold
from sklearn.manifold import TSNE
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
#os.environ['CUDA_VISIBLE_DEVICES']='0'


#------------------------------------------
#------------------------Count parameters in model------------------------------
def count_parameters(model):
  return sum(p.numel() for p in model.parameters())
#-------------------------------------------------------------------------------
#Function to flatten list
def flatten_list(_2d_list):
    flat_list = []
    for element in _2d_list:
        if type(element) is list:
            for item in element:
                flat_list.append(item)
        else:
            flat_list.append(element)
    return flat_list

#--------------------------------------------------------------------------------
#finding top n elements in a list
def Nmaxelements(list1, N):
    final_list = []

    for i in range(0, N):
        max1 = 0

        for j in range(len(list1)):
            if list1[j] > max1:
                max1 = list1[j];

        list1.remove(max1);
        final_list.append(max1)
    return final_list
#-------------------------------------------------------------------------------
#-----------------------------Read Img Function---------------------------------
def read_img(A):

    datax = []
    datay = []
    C = os.listdir(A)
    for character in C:
        images = os.listdir(A + character + '/')
        c=0
        for img in images:
          image = cv2.resize(cv2.imread(A + character + '/' + img),(80,80))
          datax.append(image)
          datay.append(character)
          c=c+1
          print(c)



    return np.array(datax), np.array(datay)
#-------------------------------------------------------------------------------
#--------------------------------Read Directory---------------------------------
def read_images(base_directory):
    """
    Reads all the alphabets from the base_directory
    Uses multithreading to decrease the reading time drastically
    """
    datax = None
    datay = None
    #pool = mp.Pool(mp.cpu_count())
    r,r1 =read_img(base_directory)
    return r,r1
#-------------------------------------------------------------------------------
#------------------Extraction of Query and Support Samples----------------------
def extract_sample(n_way, n_support, n_query, datax, datay):
  """
  Picks random sample of size n_support+n_querry, for n_way classes
  Args:
      n_way (int): number of classes in a classification task
      n_support (int): number of labeled examples per class in the support set
      n_query (int): number of labeled examples per class in the query set
      datax (np.array): dataset of images
      datay (np.array): dataset of labels
  Returns:
      (dict) of:
        (torch.Tensor): sample of images. Size (n_way, n_support+n_query, (dim))
        (int): n_way
        (int): n_support
        (int): n_query
  """
  sample = []
  K = np.random.choice(np.unique(datay), n_way, replace=False)
  for cls in K:
    datax_cls = datax[datay == cls]
    perm = np.random.permutation(datax_cls)
    sample_cls = perm[:(n_support+n_query)]
    sample.append(sample_cls)
  sample = np.array(sample)
  sample = torch.from_numpy(sample).float()
  sample1 = sample.permute(0,1,4,2,3)
  return({
      'original':sample,
      'images': sample1,
      'n_way': n_way,
      'n_support': n_support,
      'n_query': n_query
      })
#-------------------------------------------------------------------------------
#---------------------------------Model Definition------------------------------
class Flatten(nn.Module):
  def __init__(self):
    super(Flatten, self).__init__()

  def forward(self, x):
    return x.view(x.size(0), -1)

#-------------------------------------------------------------------------------
def load_protonet_conv(**kwargs):
  """
  Loads the prototypical network model
  Arg:
      x_dim (tuple): dimension of input image
      hid_dim (int): dimension of hidden layers in conv blocks
      z_dim (int): dimension of embedded image
  Returns:
      Model (Class ProtoNet)
  """
  x_dim = kwargs['x_dim']
  hid_dim = kwargs['hid_dim']
  z_dim = kwargs['z_dim']
  f_size=2
  def conv_block(in_channels, out_channels,kernel_size):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels,kernel_size, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(),
        nn.MaxPool2d(2)
        )

  encoder = nn.Sequential(
    conv_block(x_dim[0], hid_dim,f_size),
    conv_block(hid_dim, hid_dim,f_size),
    conv_block(hid_dim, hid_dim,f_size),
    conv_block(hid_dim, hid_dim,f_size),
    #conv_block(hid_dim, hid_dim,f_size),
    #conv_block(hid_dim, z_dim,f_size),
    #Flatten()
    )

  return ProtoNet(encoder)
class ProtoNet(nn.Module):
  def __init__(self, encoder):
    """
    Args:
        encoder : CNN encoding the images in sample
        n_way (int): number of classes in a classification task
        n_support (int): number of labeled examples per class in the support set
        n_query (int): number of labeled examples per class in the query set
    """
    super(ProtoNet, self).__init__()
    self.encoder = encoder.cuda()
  def set_forward_loss(self, M,sample,Max_Count_Act):
    """
    Computes loss, accuracy and output for classification task
    Args:
        sample (torch.Tensor): shape (n_way, n_support+n_query, (dim))
    Returns:
        torch.Tensor: shape(2), loss, accuracy and y_hat
    """
    sample_images = sample['images'].cuda()
    n_way = sample['n_way']
    n_support = sample['n_support']
    n_query = sample['n_query']

    x_support = sample_images[:, :n_support]
    x_query = sample_images[:, n_support:]


    #target indices are 0 ... n_way-1
    target_inds = torch.arange(0, n_way).view(n_way, 1, 1).expand(n_way, n_query, 1).long()
    target_inds = Variable(target_inds, requires_grad=False)
    target_inds = target_inds.cuda()

    #encode images of the support and the query set
    x = torch.cat([x_support.contiguous().view(n_way * n_support, *x_support.size()[2:]),
                   x_query.contiguous().view(n_way * n_query, *x_query.size()[2:])], 0)
    z = self.encoder.forward(x).to('cuda')

    z_dim = z.size(-1) #usually 64
    #support vectors and query vectors

    z_samples = z[:n_way*n_support]
    z_query = z[n_way*n_support:]

    #************************Visualization purpose******************************
    sample_orig = sample['original']
    x_support = sample_orig[:, :n_support]
    x_query = sample_orig[:, n_support:]
    #Visualize(x_query,z_query)
    #***************************************************************************
    #********Find the protytype according to the selecting technique************
    z_proto = Concept_Prototype(z_samples,n_way,n_support,Max_Count_Act)

    #*******************compute distances to prototypes*************************
    dists = euclidean_dist(z_query,z_proto)

    #**************compute probabilities,loss and accuracy**********************

    log_p_y = F.log_softmax(-dists, dim=1).view(n_way, n_query, -1)
    loss_val = -log_p_y.gather(2, target_inds).squeeze().view(-1).mean()
    _, y_hat = log_p_y.max(2)
    acc_val = torch.eq(y_hat, target_inds.squeeze()).float().mean()

    #**************************Auc Calculation**********************************

    probs = torch.exp(log_p_y)
    target_inds_flat = target_inds.reshape(-1)
    T=target_inds_flat.cpu().data.numpy()
    if n_way==2:
      probs_flat = probs.view(-1, n_way)  # Assuming 2 classes
      P=probs_flat[:, 1]
      P=P.cpu().data.numpy()
      Auc = roc_auc_score(T, P)
    else:
      probs_flat = probs.view(-1, n_way)
      P=probs_flat.cpu().data.numpy()
      Auc = roc_auc_score(T,P,average="macro", multi_class='ovo')

    #**********************F1 Calculation*********************************
    Y_pred=torch.flatten(y_hat,start_dim=0)
    Y_pred=Y_pred.cpu().data.numpy()
    if n_way==2:
      F1=f1_score(T,Y_pred)
    else:
      F1=f1_score(T,Y_pred, average='macro')
    return F1,z_samples,z_query,loss_val,Auc,{
        'loss': loss_val.item(),
        'acc': acc_val.item(),
        'y_hat': y_hat
        }
#function for forming the concept prototypes
def Concept_Prototype(z_samples,n_way,n_support,Max_Count_Act):

  #----------Selection of feature maps by global average pooling based methods--------------
  Prototypes=[]
  for i in range(n_way):
      class_samples = z_samples[i*n_support:(i+1)*n_support]
      Class_wise_prototypes=[]
      for j in class_samples:

        #***********************Selection of maps based on GAP*******************
        activation_sums = F.adaptive_avg_pool2d(j, output_size=(1)).flatten()
        # Select the indices of the top n feature maps with highest activation sum
        top_n_indices = torch.argsort(activation_sums)[-Max_Count_Act:]
        #----------------------Extract the top n feature maps--------------------
        top_n_feature_maps = j[top_n_indices]
        #***********************************************************************

        #-----------------------Making of feature maps----------------------------
        Filtered_feature_map=Mask_indices(j,top_n_indices)
        #print("Filtered_feature_map.shape",Filtered_feature_map.shape)
        Class_wise_prototypes.append(Filtered_feature_map)
      Class_wise_prototypes=torch.stack(Class_wise_prototypes)
      #print("Class_wise_prototypes.shape",Class_wise_prototypes.shape)
      Class_wise_prototypes=torch.mean(Class_wise_prototypes,0)
      Prototypes.append(Class_wise_prototypes)
  Prototypes=torch.stack(Prototypes)

  return Prototypes
#----------------------------Masking Indices------------------------------------
def Mask_indices(j,Combined_list_indices):
  mask = torch.zeros_like(j)
  mask[Combined_list_indices] = 1
  # Applying the mask
  masked_tensor = j * mask
  return masked_tensor
#------------------calculation of euclidean distance---------------------------
def euclidean_dist(x, y):
    """
    Computes euclidean distance between x and y
    Args:
        x (torch.Tensor): shape (n, c, h, w). n usually n_query, c is the number of channels, h is height, w is width.
        y (torch.Tensor): shape (m, c, h, w). m usually n_way, c is the number of channels, h is height, w is width.
    Returns:
        torch.Tensor: shape(n, m). For each query, the distances to each centroid
    """
    n = x.size(0)
    m = y.size(0)
    d = x.size(1) * x.size(2) * x.size(3)  # Flattened dimension
    assert x.size(1) == y.size(1) and x.size(2) == y.size(2) and x.size(3) == y.size(3)

    x = x.view(n, 1, d).expand(n, m, d)
    y = y.view(1, m, d).expand(n, m, d)

    return torch.pow(x - y, 2).sum(2)

#-------------------------------------------------------------------------------
def train(M, optimizer, train_x, train_y, n_way, n_support, n_query, max_epoch, epoch_size,PATH_Model,Max_Count_Act):

  #divide the learning rate by 2 at each epoch, as suggested in paper
  scheduler = optim.lr_scheduler.StepLR(optimizer, 1, gamma=0.5, last_epoch=-1)
  epoch = 0 #epochs done so far
  stop = False #status to know when to stop
  EE=datetime.datetime.now()
  count=0
  avg_F1=[]
  Train_Acc=[]
  Train_Loss=[]
  Epoch_count=[]
  while epoch < max_epoch and not stop:
    running_loss = 0.0
    running_acc = 0.0
    A_F1=0
    for episode in range(epoch_size):
      sample = extract_sample(n_way, n_support, n_query, train_x, train_y)
      optimizer.zero_grad()
      F1,z_samples,z_query,loss_val,Auc,output=M.set_forward_loss(M,sample,Max_Count_Act)
      running_loss += output['loss']
      running_acc += output['acc']
      A_F1=A_F1+F1
      loss_val.backward()
      optimizer.step()
      print('Epoch {:d} Episode {:d}'.format(epoch,episode))
    avg_F1.append(A_F1/epoch_size)
    epoch_loss = running_loss / epoch_size
    epoch_acc = running_acc / epoch_size
    Train_Acc.append(epoch_acc)
    Train_Loss.append(epoch_loss)
    Epoch_count.append(epoch)
    print('Epoch {:d} -- Loss: {:.4f} Acc: {:.4f}'.format(epoch+1,epoch_loss, epoch_acc))

    epoch=epoch+1
    scheduler.step()
  EE1=datetime.datetime.now()
  print('Training Time:',EE1-EE)
  torch.save(M.state_dict(), PATH_Model)
  best_state = M.state_dict()
  return best_state,Train_Acc,Train_Loss,Epoch_count

#-------------------------------------------------------------------------------
def test(M, test_x, test_y, n_way, n_support, n_query, test_episode,Max_Count_Act):

  avg_auc=0
  running_loss = 0.0
  running_acc = 0.0
  A_F1=0
  for episode in range(test_episode):
    sample = extract_sample(n_way, n_support, n_query, test_x, test_y)
    F1,z_samples,z_query,loss_val,Auc,output=M.set_forward_loss(M,sample,Max_Count_Act)
    A_F1=A_F1+F1
    avg_auc=avg_auc+Auc

    running_loss += output['loss']
    running_acc += output['acc']

  print('***********Testing ACC***********',running_acc/test_episode)
  print('***********Testing AUC***********',avg_auc/test_episode)
  print("***********F1-score***********",A_F1/test_episode)
  print('***********Testing Loss***********',running_loss/test_episode)

#-------------------------------------------------------------------------------

#--------------------------------Main-------------------------------------------

#-------------------------pickling of files-----------------------------------
'''trainx, trainy = read_images('/home/ranjana/Datasets/Meta-Derm7pt/Train-aug/')
testx, testy = read_images('/home/ranjana/Datasets/Meta-Derm7pt/Test/')

Path='/home/ranjana/New_pickle_files/PICKLE-FILES/Pickle-80_80/'
#Data='BC-'+str(BC_res)+'X'
Data='Derm7pt'
with open(Path+Data+"_trainx"+".pkl","wb") as f:
  pickle.dump(trainx,f)
with open(Path+Data+"_trainy"+".pkl","wb") as f:
  pickle.dump(trainy,f)
with open(Path+Data+"_testx"+".pkl","wb") as f:
  pickle.dump(testx,f)
with open(Path+Data+"_testy"+".pkl","wb") as f:
  pickle.dump(testy,f)'''

#--------------------------Parameters to change------------------------------
def main():
    #---------------seed-----------------------
    seed = int(sys.argv[1])
    seed1 = int(sys.argv[2])
    Res=str(sys.argv[3])
    n_way = int(sys.argv[4])
    n_support1 = int(sys.argv[5])
    Max_Count_Act= int(sys.argv[6]) #No.of Concepts
    max_epoch =int(sys.argv[7])
    np.random.seed(seed) 
    torch.manual_seed(seed1) 
    Data='BC-'+str(Res)
    #Data='SD-198'
    #Data='Derm7pt'
    #-------------------------parameters---------------------------
    n_support = 15
    n_query = 5
    epoch_size = 2000
    test_episode = 400
    
    Dim_channel=3
    Actual_Hid_Dim=64
    PATH='/home/ranjana/Refined-Pickle-Files/Pickle-84_84/'
    PATH_Model='/home/ranjana/New_Models/Journal/Concepts/'+'Concepts_CONV4_'+Data+'_n_way_'+str(n_way)+'_n_support1_'+str(n_support1)+'.pth'
    #-----------------------------------------------------------------------------

    model = load_protonet_conv(x_dim=(3,80,80),hid_dim=64,z_dim=64,).to('cuda')
    optimizer = optim.Adam(model.parameters(), lr = 0.001)

    with open(PATH+Data+'_trainx.pkl',"rb") as f:
      trainx = pickle.load(f)
    with open(PATH+Data+'_trainy.pkl',"rb") as f:
      trainy = pickle.load(f)
    with open(PATH+Data+'_testx.pkl',"rb") as f:
      testx = pickle.load(f)
    with open(PATH+Data+'_testy.pkl',"rb") as f:
      testy = pickle.load(f)


    print("*************************Training**********************************************")
    start=datetime.datetime.now()
    best_state,Train_Acc,Train_Loss,Epoch_count=train(model, optimizer, trainx, trainy, n_way, n_support, n_query, max_epoch, epoch_size,PATH_Model,Max_Count_Act)

    print("*************************Testing**********************************************")
    model.load_state_dict(best_state)
    model.eval()
    test(model, testx, testy, n_way, n_support1, n_query,test_episode,Max_Count_Act)
    end=datetime.datetime.now()
    print("total time taken:",end-start)
    num_params = count_parameters(model)
    print(f"Number of parameters in the model: {num_params}")
if __name__ == "__main__":
    main()
